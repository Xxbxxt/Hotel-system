<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
	<link rel="stylesheet" href="project.css">
</head>
<body>
<header>
      <div class="hotel-logo"><a href="login page/login page.php"><img src="\IMG\hotel logo.png" alt="LOGO" width="25px"></a>Seashore hotel</div>
      <ul>
        <a href="./Homepage.html">Home</a>
        <a href="./About page/about.HTML">About</a>
        <a href="./contact/contact.php">Contact</a>
        <a href="./room/rooms.php">rooms</a>
      </ul>
    </header>
	<h1> BOOK YOUR STAY</h1>
	<div class="booking-container">
	<form action="book_pro.php" id="booking-container">	
			<h3>
	
				<label for="check-in" class="label"><strong>Choose Date:</strong></label>
				<input type="date" id="check-in" required class="input">
 
			<div class="form-group">
				<label for="time" class="label"><strong>Time Slots:</strong></label>
				<select id="time" required class="input">
				<option value="09:0 AM - 10:00 AM" class="option" >09:00 AM - 10:00 AM</option>
				<option value="09:0 AM - 10:00 AM" class="option" >10:00 AM - 11:00 AM</option>
				<option value="09:0 AM - 10:00 AM" class="option" >11:00 AM - 12:00 PM</option>
				<option value="09:0 AM - 10:00 AM" class="option" >12:00 PM - 1:00 PM</option><BR>
				

				</select>
				<label for="room-type" class="label"><strong>Select Room:</strong></label>
				<select id="room-type" required class="input">
					<option value="single" class="option">Standard Room</option>
					<option value="double" class="option">Deluxe Room</option>
					<option value="suite" class="option">Premier Room</option>
					<p></p>
				</select>
				
				    <label for="name" class="label"><strong>Your Name:</strong></label>
					<input type="text" name="name" required class="input">
					<p></p>
					<label for="name" class="label"><strong>Your Email:</strong></label>
					<input type="name" name="email" required class="input">
					<p></p>
					<label for="telno" class="label"><strong>Your Phone:</strong></label>
					<input type="tel" name="phone" required class="input">
					<p></p>
					<label for="name" class="label"><strong>Your Message</strong> </label>
					<textarea name="bio" name = "message" id="Your message" required class="input" ></textarea><br>

					<label for="capture" class="label"><strong>Captcha:</strong></label>
					<input type="text" id="captcha-input"  required class="input"
					placeholder="Enter CAPTCHA code"><br>
					<button>submit</button>
			</h3>			
				
		<!-- <div class="social-links">
				<i class="fab fa-facebook"></i>
				<i class="fab fa-twitter"></i>
				<i class="fab fa-youtube"></i>
				<i class="fab fa-pinterest"></i>
				<i class="fa fa-envelope"></i>
				<i class="fab fa-instagram"></i>
        	 <div id="booking confirmation"></div> -->
	    </div>

	</form>
	</div>
	<footer>
		<div class="links">
		  <i class="fab fa-facebook"></i>
		  <i class="fab fa-twitter"></i>
		  <i class="fab fa-youtube"></i>
		  <i class="fab fa-pinterest"></i>
		  <i class="fa fa-envelope"></i>
		  <i class="fab fa-instagram"></i>
		</div>
		<p>Copy &copy 2024. All rights reserved. Designed by Tech2</p>
	  </footer>
</body>
</html>
    </div>
</body>
</html>