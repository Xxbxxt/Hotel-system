-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2024 at 06:46 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel _admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `book_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `room_type` varchar(255) NOT NULL,
  `total_number` int(10) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `arrivial` date NOT NULL,
  `departure` date NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `phone` int(15) NOT NULL,
  `ex_date` date NOT NULL,
  `message` text NOT NULL,
  `status` varchar(5) NOT NULL,
  `action` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`book_id`, `name`, `room_type`, `total_number`, `date`, `time`, `arrivial`, `departure`, `email_id`, `phone`, `ex_date`, `message`, `status`, `action`) VALUES
(21, 'Dooms', 'Suite', 5, '2024-08-16', '08:32:00', '2024-08-16', '2024-08-17', 'uygfhj@email.com', 2147483647, '0000-00-00', '', 'Activ', 0),
(22, 'Raymond atek', 'Double', 3, '2024-08-17', '11:08:00', '2024-08-17', '2024-08-17', 'uygfhj@email.com', 2147483647, '0000-00-00', '', 'Activ', 0),
(26, 'ama', 'Suite', 2, '2024-08-16', '08:22:00', '2024-08-03', '2024-08-02', 'hey@gmail.com', 2147483647, '0000-00-00', 'sfdgh', '', 0),
(27, 'Nana', 'King', 1, '2024-08-07', '08:25:00', '2024-08-03', '2024-08-02', 'hey@gmail.com', 2147483647, '0000-00-00', 'zcxvb', 'Activ', 0),
(28, 'Bernice Boateng', 'King', 1, '2024-08-09', '20:41:00', '2024-08-02', '2024-08-08', 'admin@something.com', 123456789, '0000-00-00', 'wow', 'Activ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE `guests` (
  `booking_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `room_type` varchar(255) NOT NULL,
  `total_no` int(12) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `arrival` date NOT NULL,
  `departure` date NOT NULL,
  `email_id` varchar(225) NOT NULL,
  `phone` int(12) NOT NULL,
  `status` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_no` int(12) NOT NULL,
  `room_type` varchar(225) NOT NULL,
  `AC` varchar(34) NOT NULL,
  `food` varchar(23) NOT NULL,
  `beds` varchar(12) NOT NULL,
  `status` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_no`, `room_type`, `AC`, `food`, `beds`, `status`, `message`) VALUES
(7, 'option3', 'option1', 'option3', 'option2', '', ''),
(8, 'option1', 'option1', 'option4', 'option2', '', ''),
(9, 'Double', 'AC', 'Free Lunch', '2', '', ''),
(10, 'Quad', 'NON-AC', 'Free Breakfast', '3', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `guests`
--
ALTER TABLE `guests`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `room_no` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
