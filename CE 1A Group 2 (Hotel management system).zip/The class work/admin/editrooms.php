<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest</title>
     <link rel="stylesheet" href="./CSS.css/editrooms.css">
</head>
<body>

    <div id="MySideNav" class="sidenav">
        <p class="logo"><span>S</span>easide Hotel</p>
        <a href="index.php" class="icon-a"><i class="bi bi-dashboard icons"><img src="IMG/icons8-dashboard-91.png" class="png-opacity" alt="dashboard" width="25px" title="dashboard"></i>  Dashboard</a>
        <a href="bookings.php" class="icon-a"><i class="fa fa-users icons"><img src="IMG/icons8-5-star-hotel-32.png" class="png-opacity" alt="bookings" width="25px" title="bookings"></i>  Bookings</a>
        <a href="room.php" class="icon-a"><i class="fa fa-list icons"><img src="IMG/icons8-key-64 (3).png" alt="rooms" class="png-opacity" width="25px" title="room Management"></i>  Room Management</a>
        <a href="#" class="icon-a"><i class="fa fa-shopping-bag icons"><img src="IMG/icons8-welcome-50.png" class="png-opacity" alt="guests" width="25px" title="guest management"></i>  Guest Management</a>
        <a href="staff.php" class="icon-a"><i class="fa fa-tasks icons"><img src="IMG/icons8-management-30.png" class="png-opacity" alt="staff" width="25px" title="staff management"></i>  Staff Management</a>
        <a href="reports.php" class="icon-a"><i class="fa fa-user icons"><img src="IMG/icons8-folder-bills-48.png" class="png-opacity" alt="reports" width="25px" title="reports"></i>  Reports</a>
        <a href="settings.php" class="icon-a"><i class="fa fa-list-alt icons"><img src="IMG/icons8-settings-48.png" class="png-opacity" alt="settings" width="27px" title="settings"></i>  Settings</a>
    </div>

    <div id="main">
        <div class="head">
            <div class="col-div-6">
                <span style="font-size: 30px; cursor: pointer; color: white;" class="nav"> &#9776; Room Management</span>
                <span style="font-size: 30px; cursor: pointer; color: white;" class="nav2"> &#9776; Room Management</span>
            </div>
        <div class="col-div-6">
                
        <div class="profile">
            <img src="IMG/icons8-admin-64.png" class="pro-img" width="30px" alt="administrator" title="administrator">
            <p>Wiredu Derrick<span> Admin</span></p>
        </div>
        <div class="clearfix"></div>
    </div>

    <div class="container">
        <header class="head" align="center">Add/Edit Rooms</header>

        <form action="includes/new_room.php" method="post">
            <div class="form-first">
                <div class="details personal">

                    <div class="fields">
                        <div class="input-field">
                            <label>Room ID</label>
                            <input type="text" name="room_no" placeholder="enter room id" required>
                        </div>

                        <div class="input-field">
                            <label for="options">Room Type</label>
                                <select class="options" name="room_type">
                                    <option value="option2">Select</option>
                                    <option value="Single">Single</option>
                                    <option value="Double">Double</option>
                                    <option value="Quad">Quad</option>
                                    <option value="King">King</option>
                                    <option value="Suite">Suite</option>
                                    <option value="VIlla">Villa</option>
                                </select>
                        </div>

                        <div class="input-field">
                            <label for="options">AC / NON-AC</label>
                                <select class="options" name="AC">
                                    <option value="option2">Select</option>
                                    <option value="AC">AC</option>
                                    <option value="NON-AC">NON-AC</option>
                                </select>
                        </div>

                        <div class="input-field">
                            <label for="options">Food</label>
                                <select class="options" name="food">
                                    <option value="option1">Select</option>
                                    <option value="Free Breakfast">Free Breakfast</option>
                                    <option value="Free Lunch">Free Lunch</option>
                                    <option value="Free Dinner">Free Dinner</option>
                                    <option value="Free Breakfast & Dinner">Free Breakfast & Dinner</option>
                                    <option value="Free Welcome Drink">Free Welcome Drink</option>
                                    <option value="No Free Food">No Free Food</option>
                                </select>
                        </div>

                        <div class="input-field">
                            <label for="options">Bed Count</label>
                                <select class="options" name="beds">
                                    <option value="option1">Select</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="3">5</option>
                                    <option value="6">6</option>
                                </select>
                        </div>

                        <div class="input-field">
                            <label for="options">Charges for Cancellation</label>
                                <select class="options" name="options">
                                    <option value="option2">Select</option>
                                    <option value="Free">Free</option>
                                    <option value="5% before 24hours">5% before 24hours</option>
                                    <option value="No cancellation allowe">No cancellation allowed</option>
                                </select>
                        </div>
                    </div>
                </div>

                <div class="details id">
                    <span class="title">Others</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Rent</label>
                            <input type="text" placeholder="">
                        </div>

                        <div class="input-field">
                            <label>Phone Number</label>
                            <input type="number" placeholder="Enter Contact" >
                        </div>

                        <div class="input-field" class="input-field2">
                            <label>File Upload</label>
                            <input type="file" placeholder="choose file">
                        </div>

                        <div class="input-field">
                            <label>Message</label>
                            <input type="text" name="message" placeholder="Massage">
                        </div>
                    </div>

                    <button class="nextBtn">
                        <span class="btnText"><a href="bookings.php">Done</span>
                        <i class="uil uil-navigator"></i>
                    </button>
                </div>
            </div>
        </form>



    </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(".nav").click(function(){
        $("#MySideNav").css('width','70px');
        $("#main").css('margin-left','70px');
        $(".logo").css('visibility','hidden');
        $(".logo span").css('visibility','visible');
        $(".logo span").css('margin-left','-10px');
        $(".icon-a").css('visibility','hidden');
        $(".icons").css('visibility','visible');
        $(".icons").css('margin-left','-8px');
        $(".nav").css('display','none');
        $(".nav2").css('display','block');
    });

    $(".nav2").click(function(){
        $("#MySideNav").css('width','300px');
        $("#main").css('margin-left','300px');
        $(".logo").css('visibility','visible');
        $(".logo span").css('visibility','visible');
        $(".icon-a").css('visibility','visible');
        $(".icons").css('visibility','visible');
        $(".nav").css('display','block');
        $(".nav2").css('display','none');
    });
</script>


    
</body>
</html>