<?php
    include_once("./includes/dbcon.php");

    $query = "SELECT * FROM guests";
    $result = mysqli_query($conn, $query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest page</title>
    <link rel="stylesheet" href="./CSS.css/guest.css">
</head>
<body>
    <div id="MySideNav" class="sidenav">
    <p class="logo"><span>S</span>easide Hotel</p>
    <a href="index.php" class="icon-a"><i class="bi bi-dashboard icons"><img src="IMG/icons8-dashboard-91.png" class="png-opacity" alt="dashboard" width="25px" title="dashboard"></i>  Dashboard</a>
    <a href="bookings.php" class="icon-a"><i class="fa fa-users icons"><img src="IMG/icons8-5-star-hotel-32.png" class="png-opacity" alt="bookings" width="25px" title="bookings"></i>  Bookings</a>
    <a href="room.php" class="icon-a"><i class="fa fa-list icons"><img src="IMG/icons8-key-64 (3).png" alt="rooms" class="png-opacity" width="25px" title="room Management"></i>  Room Management</a>
    <a href="#" class="icon-a"><i class="fa fa-shopping-bag icons"><img src="IMG/icons8-welcome-50.png" class="png-opacity" alt="guests" width="25px" title="guest management"></i>  Guest Management</a>
    <a href="staff.php" class="icon-a"><i class="fa fa-tasks icons"><img src="IMG/icons8-management-30.png" class="png-opacity" alt="staff" width="25px" title="staff management"></i>  Staff Management</a>
    <a href="#" class="icon-a"><i class="fa fa-user icons"><img src="IMG/icons8-folder-bills-48.png" class="png-opacity" alt="reports" width="25px" title="reports"></i>  Reports</a>
    <a href="#" class="icon-a"><i class="fa fa-list-alt icons"><img src="IMG/icons8-settings-48.png" class="png-opacity" alt="settings" width="27px" title="settings"></i>  Settings</a>
    </div>

    <div id="main">
    <div class="head">
    <div class="col-div-6">
        <span style="font-size: 30px; cursor: pointer; color: white;" class="nav"> &#9776; Guest Management</span>
        <span style="font-size: 30px; cursor: pointer; color: white;" class="nav2"> &#9776; Guest Management</span>
    </div>
    <div class="col-div-6">
        
    <div class="profile">
    <img src="IMG/icons8-admin-64.png" class="pro-img" width="30px" alt="administrator" title="administrator">
    <p>Wiredu Derrick<span> Admin</span></p>
    </div>
    <div class="clearfix"></div>
    </div>

    <div class="col-div-8" class="table-container">
    <div class="box-8">
        <div class="content-box">
            <table>
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Name</th>
                        <th>Room Type</th>
                        <th>Total Numbers</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Arrival Date</th>
                        <th>Departure Date</th>
                        <th>Email ID</th>
                        <th>Phone Number</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    while ($row = mysqli_fetch_assoc($result)) 
                    {



                    }
                    
                    
                    ?>
                    <tr>
                        <td>001</td>
                        <td>John Doe</td>
                        <td>Deluxe</td>
                        <td>2</td>
                        <td>2024-08-04</td>
                        <td>14:00</td>
                        <td>2024-08-10</td>
                        <td>2024-08-15</td>
                        <td class="protected-email">john.doe@example.com</td>
                        <td>+1234567890</td>
                        <td class="status-active">Active</td>
                        <td class="actions">
                            <button class="more-btn" onclick="toggleDropdown(this)">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                            <div class="dropdown-menu">
                                <button onclick="editBooking()">Edit</button>
                                <button onclick="deleteBooking()">Delete</button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>002</td>
                        <td>John Doe</td>
                        <td>Deluxe</td>
                        <td>2</td>
                        <td>2024-08-04</td>
                        <td>14:00</td>
                        <td>2024-08-10</td>
                        <td>2024-08-15</td>
                        <td class="protected-email">john.doe@example.com</td>
                        <td>+1234567890</td>
                        <td class="status-active">Active</td>
                        <td class="actions">
                            <button class="more-btn" onclick="toggleDropdown(this)">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                            <div class="dropdown-menu">
                                <button onclick="editBooking()">Edit</button>
                                <button onclick="deleteBooking()">Delete</button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>003</td>
                        <td>John Doe</td>
                        <td>Deluxe</td>
                        <td>2</td>
                        <td>2024-08-04</td>
                        <td>14:00</td>
                        <td>2024-08-10</td>
                        <td>2024-08-15</td>
                        <td class="protected-email">john.doe@example.com</td>
                        <td>+1234567890</td>
                        <td class="status-active">Active</td>
                        <td class="actions">
                            <button class="more-btn" onclick="toggleDropdown(this)">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                            <div class="dropdown-menu">
                                <button onclick="editBooking()">Edit</button>
                                <button onclick="deleteBooking()">Delete</button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            <br><br><p style="color: white;"> Click <a href="#top" id="down" class="ids">here </a>to scroll back to top</p>
        </div>
    </div>
    </div>




    <script>
    function toggleDropdown(button) {
        const dropdown = button.nextElementSibling;
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    }

    function editBooking() {
        alert('Edit booking functionality');
    }

    function deleteBooking() {
        alert('Delete booking functionality');
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
        if (!event.target.matches('.more-btn')) {
            const dropdowns = document.getElementsByClassName('dropdown-menu');
            for (let i = 0; i < dropdowns.length; i++) {
                const openDropdown = dropdowns[i];
                if (openDropdown.style.display === 'block') {
                    openDropdown.style.display = 'none';
                }
            }
        }
    }
    </script>

        


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(".nav").click(function(){
        $("#MySideNav").css('width','70px');
        $("#main").css('margin-left','70px');
        $(".logo").css('visibility','hidden');
        $(".logo span").css('visibility','visible');
        $(".logo span").css('margin-left','-10px');
        $(".icon-a").css('visibility','hidden');
        $(".icons").css('visibility','visible');
        $(".icons").css('margin-left','-8px');
        $(".nav").css('display','none');
        $(".nav2").css('display','block');
    });

    $(".nav2").click(function(){
        $("#MySideNav").css('width','300px');
        $("#main").css('margin-left','300px');
        $(".logo").css('visibility','visible');
        $(".logo span").css('visibility','visible');
        $(".icon-a").css('visibility','visible');
        $(".icons").css('visibility','visible');
        $(".nav").css('display','block');
        $(".nav2").css('display','none');
    });
</script>


    
</body>
</html>