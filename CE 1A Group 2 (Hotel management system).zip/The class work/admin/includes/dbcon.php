<?php 
    $conn = mysqli_connect("localhost", "me", "password", "hotel _admin");
    if (!$conn) {
        die("Connection failed: ".mysqli_connect_error());
    }

?>