<?php
require_once("../includes/dbcon.php");

if (isset($_GET['book_id'])) {
    $booking_id = intval($_GET['book_id']);

    // Prepare the delete query
    $query = "DELETE FROM booking WHERE book_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $booking_id);

    if ($stmt->execute()) {
        echo "<script>alert('Booking deleted successfully');</script>";
        echo "<script>window.location.href='../bookings.php';</script>";
    } else {
        echo "<script>alert('Error deleting booking');</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('Invalid Request');</script>";
    echo "<script>window.location.href='bookings.php';</script>";
}

$conn->close();
?>

