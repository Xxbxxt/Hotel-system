<?php
require_once("../includes/dbcon.php");

if (isset($_GET['room_no'])) {
    $room_no = intval($_GET['room_no']);

    // Prepare the delete query
    $query = "DELETE FROM rooms WHERE room_no = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $room_no);

    if ($stmt->execute()) {
        echo "<script>alert('Booking deleted successfully');</script>";
        echo "<script>window.location.href='../room.php';</script>";
        header("location:'../room.php'");
    } else {
        echo "<script>alert('Error deleting booking');</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('Invalid Request');</script>";
    echo "<script>window.location.href='../room.php';</script>";
}

$conn->close();
?>
