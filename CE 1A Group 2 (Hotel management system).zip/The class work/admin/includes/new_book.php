<?php 
include_once("../includes/dbcon.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $room_type = $_POST['room_type'];
    $number = $_POST['members'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $arrival = $_POST['arrival'];
    $departure = $_POST['departure'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message =$_POST['message'];

    $query = "INSERT INTO booking (name, room_type, total_number, date, 
                time, arrivial, departure, email_id, phone, message)
            VALUES('$name', '$room_type', '$number', '$date', '$time', '$arrival', 
            '$departure', '$email', '$phone', '$message')";

    $result = mysqli_prepare($conn, $query);

    if(mysqli_stmt_execute($result)) {
        header("location: ../Bookings.php");
    }
    else {
        echo "<script> alert('Error submitting reservation. Please try again.')</script>" ;
    }
    mysqli_stmt_close($stmt);

}
mysqli_close($conn);
?>