<?php 
include_once("../includes/dbcon.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_type = $_POST['room_type'];
    $ac = $_POST['AC'];
    $food = $_POST['food'];
    $bed = $_POST['beds'];

    $query = "INSERT INTO rooms (room_type, AC, food, beds)
            VALUES('$room_type', '$ac', '$food','$bed')";

    $result = mysqli_prepare($conn, $query);

    if(mysqli_stmt_execute($result)) {
        header("location: ../room.php");
    }
    else {
        echo "<script> alert('Error submitting reservation. Please try again.')</script>" ;
    }
    mysqli_stmt_close($stmt);

}
mysqli_close($conn);
?>