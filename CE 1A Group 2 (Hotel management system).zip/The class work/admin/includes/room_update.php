<?php 
$conn = mysqli_connect("localhost", "me", "password", "hotel _admin");

if (!$conn) {
    die("Connection failed: ".mysqli_connect_error());
}

$name = $room_type = $members = $date = $time = $arrival_date = $departure_date = $email = $phone = $status = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $booking_id = $_POST['book_id'];
    $room_id = $_POST['room_no'];
    $room_type = $_POST['room_type'];
    $ac = $_POST['AC'];
    $Food = $_POST['food'];
    $bed = $_POST['beds'];

    // Update the booking information
    $query = "UPDATE rooms SET name=?, room_type=?, total_number=?, date=?, time=?, arrivial=?, departure=?, email_id=?, phone=?, status='Active' WHERE book_id=?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssissssssi", $name, $room_type, $members, $date, $time, $arrival_date, $departure_date, $email, $phone, $booking_id);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Booking updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating booking. Please try again.');</script>";
    }

    mysqli_stmt_close($stmt);
} elseif (isset($_GET['book_id'])) {
    $booking_id = $_GET['book_id'];

    // Load the existing booking information
    $query = "SELECT * FROM rooms WHERE room_no = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $booking_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $room_id = $_POST['room_no'];
        $room_type = $_POST['room_type'];
        $ac = $_POST['AC'];
        $Food = $_POST['food'];
        $bed = $_POST['beds'];
    }

    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> room update</title>
    <link rel="stylesheet" href="../CSS.css/newbooking.css">
</head>
<body>

<div id="main">
    <div class="head">
        <div class="col-div-6">
            <span style="font-size: 30px; cursor: pointer; color: white;" class="nav"> &#9776; Update Booking</span>
            <span style="font-size: 30px; cursor: pointer; color: white;" class="nav2"> &#9776; Update Booking</span>
        </div>
        <div class="col-div-6">
            <div class="profile">
                <img src="IMG/icons8-admin-64.png" class="pro-img" width="30px" alt="administrator" title="administrator">
                <p>Wiredu Derrick<span> Admin</span></p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>

    <div class="container">
        <header class="head" align="center">Guest Details</header>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-first">
                <div class="details personal">
                    <div class="fields">
                        <div class="input-field">
                            <label>Booking ID</label>
                            <input type="number" name="book_id" value="<?php echo $booking_id; ?>" readonly>
                        </div>

                        <div class="input-field">
                            <label>Full Name</label>
                            <input type="text" name="names" value="<?php echo $name; ?>" required>
                        </div>

                        <div class="input-field">
                            <label for="options">Room Type</label>
                            <select id="options" name="room_types">
                                <option value="Single" <?php if ($room_type == "Single") echo "selected"; ?>>Single</option>
                                <option value="Double" <?php if ($room_type == "Double") echo "selected"; ?>>Double</option>
                                <option value="Quad" <?php if ($room_type == "Quad") echo "selected"; ?>>Quad</option>
                                <option value="King" <?php if ($room_type == "King") echo "selected"; ?>>King</option>
                                <option value="Suite" <?php if ($room_type == "Suite") echo "selected"; ?>>Suite</option>
                                <option value="Villa" <?php if ($room_type == "Villa") echo "selected"; ?>>Villa</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label for="options">Total Members</label>
                            <select id="options" name="membereds">
                                <option value="1" <?php if ($members == "1") echo "selected"; ?>>1</option>
                                <option value="2" <?php if ($members == "2") echo "selected"; ?>>2</option>
                                <option value="3" <?php if ($members == "3") echo "selected"; ?>>3</option>
                                <option value="4" <?php if ($members == "4") echo "selected"; ?>>4</option>
                                <option value="5" <?php if ($members == "5") echo "selected"; ?>>5</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Date</label>
                            <input type="date" name="dates" value="<?php echo $date; ?>">
                        </div>

                        <div class="input-field">
                            <label>Time</label>
                            <input type="time" name="times" value="<?php echo $time; ?>">
                        </div>
                    </div>
                </div>

                <div class="details id">
                    <span class="title">Other Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Guest Arrival Date</label>
                            <input type="date" name="arrival" value="<?php echo $arrival_date; ?>">
                        </div>

                        <div class="input-field">
                            <label>Guest Departure Date</label>
                            <input type="date" name="departure" value="<?php echo $departure_date; ?>">
                        </div>

                        <div class="input-field">
                            <label>Guest Email ID</label>
                            <input type="email" name="email" value="<?php echo $email; ?>">
                        </div>

                        <div class="input-field">
                            <label>Phone Number</label>
                            <input type="text" name="phone" value="<?php echo $phone; ?>">
                        </div>

                        <div class="input-field">
                            <label>Message</label>
                            <textarea rows="5" id="options" name="message"></textarea>
                        </div>
                    </div>
                    <a href="../bookings.php"><button type="submit" name="submit" class="nextBtn">
                        <span class="btnText">Update Booking</span>
                    </button></a>
                </div>
            </div>
            <a href="../bookings.php">
                <span class="btnText">Cancel</span>
            </a>

        </form>

    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(".nav").click(function(){
        $("#MySideNav").css('width','70px');
        $("#main").css('margin-left','70px');
        $(".logo").css('visibility','hidden');
        $(".logo span").css('visibility','visible');
        $(".logo span").css('margin-left','-10px');
        $(".icon-a").css('visibility','hidden');
        $(".icons").css('visibility','visible');
        $(".icons").css('margin-left','-8px');
        $(".nav").css('display','none');
        $(".nav2").css('display','block');
    });

    $(".nav2").click(function(){
        $("#MySideNav").css('width','300px');
        $("#main").css('margin-left','300px');
        $(".logo").css('visibility','visible');
        $(".logo span").css('visibility','visible');
        $(".icon-a").css('visibility','visible');
        $(".icons").css('visibility','visible');
        $(".nav").css('display','block');
        $(".nav2").css('display','none');
    });
</script>


    
</body>
</html>
