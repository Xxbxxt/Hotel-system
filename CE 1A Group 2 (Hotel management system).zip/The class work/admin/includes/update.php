<?php 
include_once("../includes/dbcon.php");

if (isset($_POST['submit'])) {
    $booking_id = $_POST['book_id'];
    $name = $_POST['names'];
    $room_type = $_POST['room_types'];
    $members = $_POST['membereds'];
    $date = $_POST['dates'];
    $time = $_POST['times'];
    $arrival_date = $_POST['arrival'];
    $departure_date = $_POST['departure'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

    // Prepared statement to update the record
    $query = "UPDATE booking SET name=?, room_type=?, total_number=?, date=?, time=?, arrival=?, departure=?, email_id=?, phone=?, status='Active' WHERE book_id=?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssissssssi", $name, $room_type, $members, $date, $time, $arrival_date, $departure_date, $email, $phone, $booking_id);

    if (mysqli_stmt_execute($stmt)) {
        header("location: ../bookings.php");
    } else {
        echo "<script>alert('Error submitting reservation. Please try again.')</script>";
    }

    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
?>
