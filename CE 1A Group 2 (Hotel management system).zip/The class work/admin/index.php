<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Wiredu Derrick Sarfo">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seaside Hotel - Admin Dashboard</title>
    <link rel="stylesheet" href="./CSS.css/style.css">
</head>
<body>
    <nav>
        <div id="MySideNav" class="sidenav">
            <p class="logo"><span>S</span>easide Hotel</p>
            <a href="#" class="icon-a"><i class="bi bi-dashboard icons"><img src="./IMG/icons8-dashboard-91.png" class="png-opacity" alt="dashboard" width="25px" title="dashboard"></i>  Dashboard</a>
            <a href="bookings.php" class="icon-a"><i class="fa fa-users icons"><img src="IMG/icons8-5-star-hotel-32.png" class="png-opacity" alt="bookings" width="25px" title="bookings"></i>  Bookings</a>
            <a href="room.php" class="icon-a"><i class="fa fa-list icons"><img src="IMG/icons8-key-64 (3).png" alt="rooms" class="png-opacity" width="25px" title="room Management"></i>  Room Management</a>
            <a href="guest.php" class="icon-a"><i class="fa fa-shopping-bag icons"><img src="IMG/icons8-welcome-50.png" class="png-opacity" alt="guests" width="25px" title="guest management"></i>  Guest Management</a>
            <a href="staff.php" class="icon-a"><i class="fa fa-tasks icons"><img src="IMG/icons8-management-30.png" class="png-opacity" alt="staff" width="25px" title="staff management"></i>  Staff Management</a>
            <a href="#" class="icon-a"><i class="fa fa-user icons"><img src="IMG/icons8-folder-bills-48.png" class="png-opacity" alt="reports" width="25px" title="reports"></i>  Reports</a>
            <a href="#" class="icon-a"><i class="fa fa-list-alt icons"><img src="IMG/icons8-settings-48.png" class="png-opacity" alt="settings" width="27px" title="settings"></i>  Settings</a>
        </div>
    </nav>
    
    <div id="main">
        <div class="head">
            <div class="col-div-6">
                <span style="font-size: 30px; cursor: pointer; color: white;" class="nav"> &#9776; Dashboard</span>
                <span style="font-size: 30px; cursor: pointer; color: white;" class="nav2"> &#9776; Dashboard</span>
            </div>
        <div class="col-div-6">
                
        <div class="profile">
            <img src="IMG/icons8-admin-64.png" class="pro-img" width="30px" alt="administrator" title="administrator">
            <p>Wiredu Derrick<span> Admin</span></p>
        </div>

        <div class="clearfix"></div>
        </div>

        <div class="col-div-3">
            <div class="box">
                <p>136<br/><span>Total Booking</span></p>
                <i class="fa fa-users box-icon"></i>
            </div>
        </div>

        <div class="col-div-3">
            <div class="box">
                <p>88<br/><span>Available Rooms</span></p>
                <i class="fa fa-list box-icon"></i>
            </div>
        </div>

        <div class="col-div-3">
            <div class="box">
                <p>99<br/><span>Enquiry</span></p>
                <i class="fa fa-shopping-bag box-icon"></i>
            </div>
        </div>

        <div class="col-div-3">
            <div class="box">
                <p>323<br/><span>Collections</span></p>
                <i class="fa fa-tasks box-icon"></i>
            </div>
        </div>

        <div class="clearfix"></div>
        <br/><br/>

        <div class="col-div-8">
            <div class="box-8">
                <div class="content-box">

    <p>Latest Bookings <span><a href="bookings.php" style="text-decoration: none; color: #a50e09;" target="_blank">View All</a></span></p>
                    <br/>
                    <table>
                        <tr>
                            <th>Booking ID</th>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Room Type</th>
                        </tr>
                        <tr>
                            <td>BKG-0001</td>
                            <td>Alfreds</td>
                            <td>+233-599-345-949</td>
                            <td>Double</td>
                        </tr>
                        <tr>
                            <td>BKG-0002</td>
                            <td>Bro Coder</td>
                            <td>+233-27-777-6160</td>
                            <td>Single</td>
                        </tr>
                        <tr>
                            <td>BKG-0003</td>
                            <td>Mosh</td>
                            <td>+233-50-5379-537</td>
                            <td>Double</td>
                        </tr>
                        <tr>
                            <td>BKG-0004</td>
                            <td>Marvin</td>
                            <td>+233-50-858-7978</td>
                            <td>Double</td>
                        </tr>
                        <tr>
                            <td>BKG-0005</td>
                            <td>Arden-Clarke</td>
                            <td>+233-24-4470-134</td>
                            <td>Single</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-div-4">
            <div class="box-4">
                <div class="content-box">
                    <p>Rooms Booked<span><a href="bookings.php" target="_blank" style="text-decoration: none; color: #a50e09;">View All</a></span></p>
                    <div class="circle-wrap">
                    <div class="circle">
                        <div class="mask full">
                            <div class="fill"></div>
                        </div>
                        <div class="mask half">
                            <div class="fill"></div>
                        </div>
                        <div class="inside-circle">70%</div>
                    </div>
                </div>
                <h5  align="center" style="color: #ddd;">Percentage Rate of Hotel Facilities booked per day.</h5>
            </div>
            </div>
        </div>

        <div class="clearfix">





    </div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(".nav").click(function(){
        $("#MySideNav").css('width','70px');
        $("#main").css('margin-left','70px');
        $(".logo").css('visibility','hidden');
        $(".logo span").css('visibility','visible');
        $(".logo span").css('margin-left','-10px');
        $(".icon-a").css('visibility','hidden');
        $(".icons").css('visibility','visible');
        $(".icons").css('margin-left','-8px');
        $(".nav").css('display','none');
        $(".nav2").css('display','block');
    });

    $(".nav2").click(function(){
        $("#MySideNav").css('width','300px');
        $("#main").css('margin-left','300px');
        $(".logo").css('visibility','visible');
        $(".logo span").css('visibility','visible');
        $(".icon-a").css('visibility','visible');
        $(".icons").css('visibility','visible');
        $(".nav").css('display','block');
        $(".nav2").css('display','none');
    });
</script>

</body>
</html>