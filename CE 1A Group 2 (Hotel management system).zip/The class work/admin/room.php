
<?php
    include_once("./includes/dbcon.php");

    $query = "SELECT * FROM rooms";
    $result = mysqli_query($conn, $query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room</title>
    <link rel="stylesheet" href="./CSS.css/room.css">
</head>
<body>

    <div id="MySideNav" class="sidenav">
        <p class="logo"><span>S</span>easide Hotel</p>
        <a href="index.php" class="icon-a"><i class="bi bi-dashboard icons"><img src="IMG/icons8-dashboard-91.png" class="png-opacity" alt="dashboard" width="25px" title="dashboard"></i>  Dashboard</a>
        <a href="bookings.php"  class="icon-a"><i class="fa fa-users icons"><img src="IMG/icons8-5-star-hotel-32.png" class="png-opacity" alt="bookings" width="25px" title="bookings"></i>  Bookings</a>
        <a href="#" class="icon-a"><i class="fa fa-list icons"><img src="IMG/icons8-key-64 (3).png" alt="rooms" class="png-opacity" width="25px" title="room Management"></i>  Room Management</a>
        <a href="guest.php" class="icon-a"><i class="fa fa-shopping-bag icons"><img src="IMG/icons8-welcome-50.png" class="png-opacity" alt="guests" width="25px" title="guest management"></i>  Guest Management</a>
        <a href="staff.php" class="icon-a"><i class="fa fa-tasks icons"><img src="IMG/icons8-management-30.png" class="png-opacity" alt="staff" width="25px" title="staff management"></i>  Staff Management</a>
        <a href="#" class="icon-a"><i class="fa fa-user icons"><img src="IMG/icons8-folder-bills-48.png" class="png-opacity" alt="reports" width="25px" title="reports"></i>  Reports</a>
        <a href="#" class="icon-a"><i class="fa fa-list-alt icons"><img src="IMG?icons8-settings-48.png" class="png-opacity" alt="settings" width="27px" title="settings"></i>  Settings</a>
    </div>

                
    <div id="main" id="top">
        <di class="head">
            <div class="col-div-6">
                <span style="font-size: 30px; cursor: pointer; color: white;" class="nav"> &#9776; Room Management</span>
                <span style="font-size: 30px; cursor: pointer; color: white;" class="nav2"> &#9776; Room Management</span>
            </div>

            <div>
                <a href="editrooms.php" class="guest">Edit Rooms</a>
            </div>

        <div class="col-div-6">
                
        <div class="profile">
            <img src="IMG/icons8-admin-64.png" class="pro-img" width="30px" alt="administrator" title="administrator">
            <p>Wiredu Derrick<span><a href="#down" class="ids"> Admin</a></span></p>
        </div>
        <div class="clearfix"></div>
    </div>
    
    <div class="col-div-8" class="table-container">
        <div class="box-8">
            <div class="content-box">
                <table>
                    <thead>
                        <tr>
                            <th>Room Number</th>
                            <th>Room Type</th>
                            <th>AC / NON-AC</th>
                            <th>Food</th>
                            <th>Bed Count</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>

                        <?php
                        while ($row = mysqli_fetch_assoc($result)) 
                        {
                            $room_no = $row['room_no'];
                            $room_type = $row['room_type'];
                            $ac = $row['AC'];
                            $Food = $row['food'];
                            $bed = $row['beds'];
                        
                        ?>
                            <td><?php echo $room_no;?></td>
                            <td><?php echo $room_type;?></td>
                            <td><?php echo $ac;?></td>
                            <td><?php echo $Food;?></td>
                            <td><?php echo $bed;?></td>
                            <td class="status-active">Active</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                <a href="../admin/includes/room_update.php?book_id=<?php echo $rppm_no; ?>"><button onclick="editBooking()">Edit</button></a>
                                <a href="../admin/includes/delete_room.php?book_id=<?php echo $room_no; ?>"><button onclick="deleteBooking()" name="update">Delete</button></a>
                                </div>
                            </td>
                        </tr>
                        <?php
                        }?>
                        <tr>
                            <td>002</td>
                            <td>Single</td>
                            <td>AC</td>
                            <td>Free Dinner</td>
                            <td>1</td>
                            <td class="status-active">Inactive</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <a href="../admin/includes/room_update.php?book_id=<?php echo $rppm_id; ?>"><button onclick="editBooking()">Edit</button></a>
                                    <a href="../admin/includes/delete_room.php?book_id=<?php echo $room_id; ?>"><button onclick="deleteBooking()" name="update">Delete</button></a>
                                </div>
                                </div>
                            </td>
                        </tr>
                </tbody>
            </table>
            <br><br><p style="color: white;"> Click <a href="#top" id="down" class="ids">here </a>to scroll back to top</p>
        </div>
    </div>
</div>




<script>
    function toggleDropdown(button) {
        const dropdown = button.nextElementSibling;
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    }

    function editBooking() {
        alert('Edit booking functionality');
    }

    function deleteBooking() {
        alert('Delete booking functionality');
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
        if (!event.target.matches('.more-btn')) {
            const dropdowns = document.getElementsByClassName('dropdown-menu');
            for (let i = 0; i < dropdowns.length; i++) {
                const openDropdown = dropdowns[i];
                if (openDropdown.style.display === 'block') {
                    openDropdown.style.display = 'none';
                }
            }
        }
    }
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(".nav").click(function(){
        $("#MySideNav").css('width','70px');
        $("#main").css('margin-left','70px');
        $(".logo").css('visibility','hidden');
        $(".logo span").css('visibility','visible');
        $(".logo span").css('margin-left','-10px');
        $(".icon-a").css('visibility','hidden');
        $(".icons").css('visibility','visible');
        $(".icons").css('margin-left','-8px');
        $(".nav").css('display','none');
        $(".nav2").css('display','block');
    });

    $(".nav2").click(function(){
        $("#MySideNav").css('width','300px');
        $("#main").css('margin-left','300px');
        $(".logo").css('visibility','visible');
        $(".logo span").css('visibility','visible');
        $(".icon-a").css('visibility','visible');
        $(".icons").css('visibility','visible');
        $(".nav").css('display','block');
        $(".nav2").css('display','none');
    });
</script>



    