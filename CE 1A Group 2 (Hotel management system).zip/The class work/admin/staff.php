<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff</title>
    <link rel="stylesheet" href="CSS.css/staff.css">
    <link rel="stylesheet" href="CSS.css/staffstyle.css">
    <link rel="icon" type="image/x-icon" href="s.jpg">
</head>
<body>

    <div id="MySideNav" class="sidenav">
        <p class="logo"><span>S</span>easide Hotel</p>
        <a href="index.php" class="icon-a"><i class="bi bi-dashboard icons"><img src="IMG/icons8-dashboard-91.png" class="png-opacity" alt="dashboard" width="25px" title="dashboard"></i>  Dashboard</a>
        <a href="bookings.php" class="icon-a"><i class="fa fa-users icons"><img src="IMG/icons8-5-star-hotel-32.png" class="png-opacity" alt="bookings" width="25px" title="bookings"></i>  Bookings</a>
        <a href="room.php" class="icon-a"><i class="fa fa-list icons"><img src="IMG/icons8-key-64 (3).png" alt="rooms" class="png-opacity" width="25px" title="room Management"></i>  Room Management</a>
        <a href="guest.php" class="icon-a"><i class="fa fa-shopping-bag icons"><img src="IMG/icons8-welcome-50.png" class="png-opacity" alt="guests" width="25px" title="guest management"></i>  Guest Management</a>
        <a href="#" class="icon-a"><i class="fa fa-tasks icons"><img src="IMG/icons8-management-30.png" class="png-opacity" alt="staff" width="25px" title="staff management"></i>  Staff Management</a>
        <a href="reports.php" class="icon-a"><i class="fa fa-user icons"><img src="IMG/icons8-folder-bills-48.png" class="png-opacity" alt="reports" width="25px" title="reports"></i>  Reports</a>
        <a href="settings/settings.php" class="icon-a"><i class="fa fa-list-alt icons"><img src="IMG/icons8-settings-48.png" class="png-opacity" alt="settings" width="27px" title="settings"></i>  Settings</a>
    </div>

    <div id="main">
        <div class="head">
        <div class="col-div-6">
            <span style="font-size: 30px; cursor: pointer; color: white;" class="nav"> &#9776; Staff Management</span>
            <span style="font-size: 30px; cursor: pointer; color: white;" class="nav2"> &#9776; Staff Management</span>
        </div>
        <div class="col-div-6">
            
        <div class="profile">
        <img src="IMG/icons8-admin-64.png" class="pro-img" width="30px" alt="administrator" title="administrator">
        <p>Wiredu Derrick<span> Admin</span></p>
        </div>
        <div class="clearfix"></div>
        </div><br><br>

        <div class="container">
                <form action="newstaff.html" method="post">
                    <div class="form-first">
                        <div class="details personal">

                            <div class="fields">
                                <div class="input-field">
                                    <label>Employee ID</label>
                                    <input type="text" placeholder="">
                                </div>

                                <div class="input-field">
                                    <label>Employee Name</label>
                                    <input type="text" placeholder="">
                                </div>

                                <div class="input-field">
                                    <label for="options">Role</label>
                                        <select id="options" name="options">
                                            <option value="option2">Select</option>
                                            <option value="option1">Admin</option>
                                            <option value="option2">Manager</option>
                                            <option value="option3">Receptionist</option>
                                            <option value="option4">Room Attendant</option>
                                            <option value="option3">Chef</option>
                                            <option value="option4">Driver</option>
                                        </select>
                                </div>

                            <button type="submit" class="nextBtn">
                                <span class="btnText"><a href="newstaff.html">Add Staff</span>
                                <i class="uil uil-navigator"></i>
                            </button>
                            <button type="submit" formaction="#" class="searchBtn" id="srch">
                                <span class="search"><a href="#">Search</span>
                                <i class="uil uil-navigator"></i>
                            </button>
                        </div>
                    </div>
                </form>
        </div>

    
        <div class="col-div-8" class="table-container">
        <div class="box-8">
            <div class="content-box">
                <table>
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Join Date</th>
                            <th>Role</th>
                            <th>Salary($)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>001</td>
                            <td>Gyau Nathaniel</td>
                            <td>gnathaniel@gmail.com</td>
                            <td>0234567890</td>
                            <td>2017-08-04</td>
                            <td>Manager</td>
                            <td>6,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>002</td>
                            <td>Menash Jarvis</td>
                            <td>lordmensah@gmail.com</td>
                            <td>0234567890</td>
                            <td>2019-08-04</td>
                            <td>Accountant</td>
                            <td>3,500</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>003</td>
                            <td>Quaye Mambley</td>
                            <td>mambley1234@gmail.com</td>
                            <td>0234567890</td>
                            <td>2017-08-04</td>
                            <td>Cleaner</td>
                            <td>1,500</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>004</td>
                            <td>Appiah Kwaku</td>
                            <td>klamar234@gmail.com</td>
                            <td>0234567890</td>
                            <td>2020-10-09</td>
                            <td>Driver</td>
                            <td>2,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>005</td>
                            <td>Anokye Frank</td>
                            <td>postarr789@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Room Maintainer</td>
                            <td>1,250</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td>006</td>
                            <td>Selikem Christabel</td>
                            <td>selikem@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Receptionist</td>
                            <td>2,500</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>007</td>
                            <td>Sarfo Newman</td>
                            <td>akokoa@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Driver</td>
                            <td>2,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
    
                        <tr>
                            <td>008</td>
                            <td>Brown Anita</td>
                            <td>postarr789@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Room Attendant</td>
                            <td>1,200</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
    
                        <tr>
                            <td>009</td>
                            <td>Newman Alpha</td>
                            <td>alphaandomega@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Cleaner</td>
                            <td>1,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td>010</td>
                            <td>Twumasi Isaac</td>
                            <td>trapbaby@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Accountant</td>
                            <td>3,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
    
                        <tr>
                            <td>011</td>
                            <td>Aboagye Anabel</td>
                            <td>annieaboa419@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Chef</td>
                            <td>2,500</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
    
                        <tr>
                            <td>012</td>
                            <td>Menash Jarvis</td>
                            <td>lordmensah@gmail.com</td>
                            <td>0234567890</td>
                            <td>2019-08-04</td>
                            <td>Accountant</td>
                            <td>3,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>013</td>
                            <td>Quaye Mambley</td>
                            <td>mambley1234@gmail.com</td>
                            <td>0234567890</td>
                            <td>2017-08-04</td>
                            <td>Cleaner</td>
                            <td>1,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>014</td>
                            <td>Appiah Kwaku</td>
                            <td>klamar234@gmail.com</td>
                            <td>0234567890</td>
                            <td>2020-10-09</td>
                            <td>Driver</td>
                            <td>2,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>015</td>
                            <td>Anokye Frank</td>
                            <td>postarr789@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Room Maintainer</td>
                            <td>1,200</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td>016</td>
                            <td>Selikem Christabel</td>
                            <td>selikem@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Receptionist</td>
                            <td>2,500</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>017</td>
                            <td>Sarfo Newman</td>
                            <td>akokoa@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Driver</td>
                            <td>2,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>018</td>
                            <td>Brown Anita</td>
                            <td>postarr789@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Room Attendant</td>
                            <td>1,500</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>019</td>
                            <td>Newman Alpha</td>
                            <td>alphaandomega@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Cleaner</td>
                            <td>1,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                        <tr>
                            <td>020</td>
                            <td>Aboagye Anabel</td>
                            <td>annieaboa419@gmail.com</td>
                            <td>0234567890</td>
                            <td>2023-07-04</td>
                            <td>Events Overseer</td>
                            <td>2,000</td>
                            <td class="actions">
                                <button class="more-btn" onclick="toggleDropdown(this)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                                <div class="dropdown-menu">
                                    <button onclick="editBooking()">Edit</button>
                                    <button onclick="deleteBooking()">Delete</button>
                                </div>
                            </td>
                        </tr>
    
                    </tbody>
                </table>
                
            </div>
        </div>
        </div>
       
    
    
    
        <script>
        function toggleDropdown(button) {
            const dropdown = button.nextElementSibling;
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        }
    
        function editBooking() {
            alert('Edit booking functionality');
        }
    
        function deleteBooking() {
            alert('Delete booking functionality');
        }
    
        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.more-btn')) {
                const dropdowns = document.getElementsByClassName('dropdown-menu');
                for (let i = 0; i < dropdowns.length; i++) {
                    const openDropdown = dropdowns[i];
                    if (openDropdown.style.display === 'block') {
                        openDropdown.style.display = 'none';
                    }
                }
            }
        }
        </script>
    
            
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script>
        $(".nav").click(function(){
            $("#MySideNav").css('width','70px');
            $("#main").css('margin-left','70px');
            $(".logo").css('visibility','hidden');
            $(".logo span").css('visibility','visible');
            $(".logo span").css('margin-left','-10px');
            $(".icon-a").css('visibility','hidden');
            $(".icons").css('visibility','visible');
            $(".icons").css('margin-left','-8px');
            $(".nav").css('display','none');
            $(".nav2").css('display','block');
        });
    
        $(".nav2").click(function(){
            $("#MySideNav").css('width','300px');
            $("#main").css('margin-left','300px');
            $(".logo").css('visibility','visible');
            $(".logo span").css('visibility','visible');
            $(".icon-a").css('visibility','visible');
            $(".icons").css('visibility','visible');
            $(".nav").css('display','block');
            $(".nav2").css('display','none');
        });
    </script>
    
    <p style="color: white;">Click <a id="down" class="ids">here </a>to scroll back to top</p>

    
</body>
</html>