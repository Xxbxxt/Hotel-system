<?php

    require_once("includes/dbconn.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST["date"];
    $time = $_POST["time"];
    $room_type = $_POST["room_type"];
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    //$message = $_POST["message"];

    // Making the insert queries
    $query = "INSERT INTO booking (date, time, room_type, name, email_id, phone) 
              VALUES ('$date', '$time', '$room_type', '$name', '$email', '$phone')";

    $stmt = mysqli_prepare($conn, $query);
   
    
    if (mysqli_stmt_execute($stmt)) {
        // Reservation successfully added
        header("location: Booking.php"); // Redirect to a page confirming the reservation
        exit();
    } else {
        echo "Error submitting reservation. Please try again.";
    }
    
    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
?>


