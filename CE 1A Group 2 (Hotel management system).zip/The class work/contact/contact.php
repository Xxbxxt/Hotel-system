<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>contact form</title>
    <link rel="stylesheet" href="contact.css">
</head>
<body>
<header>
      <ul>
        <a href="../Homepage.html">Home</a>
        <a href="../About page/about.HTML">About</a>
        <a href="../contact/contact.php">Contact</a>
        <a href="../room/rooms.php">rooms</a>
      </ul>
      <button><a href="../Booking.php">booking</a></button>
    </header>
    <div class="contact-us">
        <div class="title">
            <h2>Contact us</h2>
        </div>
        <div class="box">
            <!--form-->
           <div class="contact forms">
              <h3>Send a Message</h3>
              <form>
                <div class="formbox">
                    <div class="row50">
                        <div class="inputbox">
                            <label>Name</label>
                            <input type="text">
                        </div>
                        <div class="inputbox">
                            <label>Address</label>
                            <input type="text">
                        </div>
                    </div>
                    <div class="row50">    
                        <div class="inputbox">
                            <label>Phone</label>
                            <input type="text">
                        </div>
                        <div class="inputbox">
                            <label>Email</label>
                            <input type="text">
                        </div>
                    </div>
                    <div class="row100">   
                        <div class="inputbox">
                            <label>Message</label>
                            <textarea type="text"></textarea>
                        </div>
                    </div>
                    <div class="row100">
                        <div class="inputbox">
                            <input type="submit" value="Send">
                        </div>
                    </div>
                </div>
              </form>
           </div>
           <!--Info box--> 
           <div class="contact info">
              <h3>Contact Us</h3>
              <div class="infobox">
                <div>
                    <label><ion-icon name="location"></ion-icon>Location:</label>
                    <p>Diamond Hill(hilltop),Kumasi<br>Ghana</p>
                </div>
                <div>
                    <label><ion-icon name="mail"></ion-icon>Email:</label>
                    <p>serwaahnhyirahjohnson17@gmail.com</p>
                </div>
                <div>
                    <label><ion-icon name="call"></ion-icon>
                        Tel:</label>
                    <p>+233 552 872 500</p>
                </div>
              </div>
           </div> 
           <!--map-->
           <div class="contact map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3962.7099348324577!2d-1.6765044999999998!3d6.682809799999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfdb99c3eb63599b%3A0x7222d8485dfe3ba1!2sDiamond%20Hill%20Residency!5e0!3m2!1sen!2sgh!4v1722296859499!5m2!1sen!2sgh"  allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
           </div> 
        </div>
    </div>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

<footer>
    <div class="footercontainer">
        <div class="socialIcons">
            <label><ion-icon name="logo-facebook"></ion-icon></label>
            <label><ion-icon name="logo-instagram"></ion-icon></label>
            <label><ion-icon name="logo-whatsapp"></ion-icon></label>
            <label><ion-icon name="logo-twitter"></ion-icon></label>
            <label><ion-icon name="logo-tiktok"></ion-icon></label>
    
        </div>
        <div class="footerNav">
            <ul>
                <li><a href="">Home</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Rooms</a></li>
                <li><a href="">Booking</a></li>
                <li><a href="">Offers</a></li>
                <li><a href="">Gallery</a></li>
                <li><a href="">Contact</a></li>
    
            </ul> 
        </div>
        <div class="footerbottom">
            <p>CopyRight &copy;2024;Designed by <label for="designer">Serwaah Nhyirah Johnson and Henry Abankwah </label></p>
        </div>
    </div>
</footer>
</body>
</html>