<?php 
require_once("./include/dbconn.php");

if ($_GET['Del']) {
    $user_id = $_GET['Del'];
    $query = "DELETE FROM register WHERE userID = '$user_id";
    $result = mysqli_query($conn, $query);
    header("location:view.php");
}
?>