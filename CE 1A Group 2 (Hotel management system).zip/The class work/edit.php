<?php 
require_once('./includes/dbconn.php');

if (isset($_GET['GetID'])) {
    $query = "update ";


}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./CSS/bootstrap.min.css">
</head>
<body>
<div class="container">
        <div class="row">
            <div class="col-lg-6 m-auto">
                <div class="card mt-5">
                    <div class="card-title">
                        <h3 class="bg-info text-white text-center py-3">Reservation Form</h3>
                    </div>
                    <div class="card-body">
                        <form action="process_reservation.php" method="post">
                            <label for="room_type">Select Room Type:</label>
                            <select name="room_type" class="form-control mb-2" required>
                                <option value="Deluxe Room">Deluxe Room</option>
                                <option value="Executive Suite">Executive Suite</option>
                                <option value="Budget Friendly">Budget Friendly</option>
                               
                                <!-- Add more room options as needed -->
                                
                            </select>
                            <label for="customer_name">Full Name:</label>
                            <input type="text" name="customer_name" class="form-control mb-2" placeholder="Your Name" required>
                            <label for="customer_email">Email:</label>
                            <input type="email" name="customer_email" class="form-control mb-2" placeholder="Your Email" required>
                            <label for="check_in_date">Check-In Date:</label>
                            <input type="date" name="check_in_date"  class="form-control mb-2" required>
                            <label for="check_out_date">Check-Out Date:</label>
                            <input type="date" name="check_out_date" class="form-control mb-2" required>
                            <label for="additional_details"> additional Info:</label>
                            <textarea name="additional_details" class="form-control mb-2" placeholder="Additional Details"></textarea>
                            <button type="submit" class="btn btn-primary" name="submit">Submit Reservation</button>
                       </form>
                    </div>   
                </div>
            </div>     
        </div>
    </div>
</body>
</html>