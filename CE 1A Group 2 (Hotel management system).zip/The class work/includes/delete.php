<?php 

require_once("../includes/dbconn.php");

if ($_GET['Del']) {
    $user_id = $_GET['Del'];
    $query = "DELETE FROM bookings WHERE user_id = $user_id";
    $result = mysqli_query($conn, $query);
    header("location:view.php");
}
?>