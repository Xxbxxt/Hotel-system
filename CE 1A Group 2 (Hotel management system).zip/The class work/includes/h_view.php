<?php

$servername = "localhost";
$username = "me";
$password = "password";
$dbname = "hotel_m_system";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
 
 $query = "SELECT * FROM reservations";
    $result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VIEW</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link ref="icon" type="image/x-icon" href="img\2022_09_09_20_10_IMG_0044.JPG" />
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light bg-info">
        <a class="navbar-brand" href="#"><img src='img\2023_06_07_15_02_IMG_0371.JPG' alt="Home Page" width="30"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="true"> 
           <span class="navbar-toggler-icon"></span> 
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
               <a class="nav-item nav-link text-white" href="#">Home </a>
               <a class="nav-item nav-link active" href="#">View Info <span class="sr-only">(current)</a>
            </div>
        </div>    
    </nav>

    <div class="container">
        <div class="row">
            <div class="col m-auto">
                <div class="card mt-5">
                    <div class="card-title">
                        <h3 class="bg-secondary text-white text-center py-3">Reservations</h3>
                    </div>
                    <div class="card-body">
                        <!-- <p><a class="btn btn-info text-area" href="CRUD_FORM.php">+ Add New Record </a> </p> -->
                        <table class="table table-bordered">
                        <tr>
                            <td>User ID</td>
                            <td>Time</td>
                            <td>Room Type</td>
                            <td>Customer name</td>
                            <td>Customer Email</td>
                            <td>Phone</td>
                            <td>Additional Details</td>
                        </tr>
                        <?php
                            while($row = mysqli_fetch_assoc($result))
                            {
                                //$UserID = $row['user_id'];
                                $RoomType = $row['room_type'];
                                $ClientName = $row['name'];
                                $Email = $row['email'];
                                $date = $row['date'];
                                $time = $row['time'];
                                $AddInfo = $row['message'];

                                ?>

                                <tr>
                                    <td>ID</td>
                                    <td><?php echo$time ?></td>
                                    <td><?php echo $RoomType ?></td>
                                    <td><?php echo $ClientName?></td>
                                    <td><?php echo $Email ?></td>
                                    <td><?php echo $date ?></td>
                                    <td><?php echo $time ?></td>
                                    <td><?php echo $AddInfo?></td>
                                    <td>
                                        <a class="btn btn-info text-white" href="edit.php?GetID=<?php echo $UserID ?>">Edit</a> | <a class="btn btn-danger text-white" href="delete.php?Del=<?php echo $UserID ?>">Delete </a>
                                    </td>
                                </tr>  
                                <?php 
                            } ?>

                         
                       
                        </table>
                       
                    </div>   
                </div>
            </div>     
        </div>
    </div>
</body>
</html>