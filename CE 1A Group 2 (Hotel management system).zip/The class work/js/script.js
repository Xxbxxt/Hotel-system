const toTop = document.querySelector(".to-top");

window.addEventListener("scroll", () => {
  if (window.pageYOffset > 100) {
    toTop.classList.add("active");
  } else {
    toTop.classList.remove("active");
  }
});

// script for the slider
// Write JavaScript code here
document.addEventListener("DOMContentLoaded", function () {
  console.log("Welcome");
});

document.addEventListener("DOMContentLoaded", function () {
  const rightArrow = document.getElementById("right");
  const carousel = document.querySelector(".carousel");

  // Function to handle clicking on the right arrow
  rightArrow.addEventListener("click", function () {
    carousel.scrollBy({
      left: 250,
      behavior: "smooth",
    });
  });
});

document.addEventListener("DOMContentLoaded", function () {
  const leftArrow = document.getElementById("left");
  const carousel = document.querySelector(".carousel");

  // Function to handle clicking on the left arrow
  leftArrow.addEventListener("click", function () {
    carousel.scrollBy({
      left: -250,
      behavior: "smooth",
    });
  });
});
