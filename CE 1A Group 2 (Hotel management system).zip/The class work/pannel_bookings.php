<?php

  require_once("includes/dbconn.php");
 
  $query = "SELECT * FROM reservations";
  $result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Wiredu Derrick Sarfo">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seaside Hotel - Admin Dashboard</title>
    <link rel="stylesheet" href="./CSS/pannel_bookings.css">
    <link rel="stylesheet" href="./CSS/newbooking.css">
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link ref="icon" type="image/x-icon" href="img\2022_09_09_20_10_IMG_0044.JPG" />
</head>
<body>
    <div id="MySideNav" class="sidenav">
        <p class="logo"><span>S</span>easide Hotel</p>
        <a href="pannel.html" class="icon-a"><i class="bi bi-dashboard icons"></i><img src="speedometer2.svg"></img>Dashboard</a>
        <a href="pannel_bookings.php" class="icon-a"><i class="fa fa-users icons"></i>&nbsp;&nbsp; Bookings</a>
        <a href="room_manage.php" class="icon-a"><i class="fa fa-list icons"></i>&nbsp;&nbsp; Room Management</a>
        <a href="#" class="icon-a"><i class="fa fa-shopping-bag icons"></i>&nbsp;&nbsp; Guest Management</a>
        <a href="#" class="icon-a"><i class="fa fa-tasks icons"></i>&nbsp;&nbsp; Staff Management</a>
        <a href="#" class="icon-a"><i class="fa fa-user icons"></i>&nbsp;&nbsp; Reports</a>
        <a href="#" class="icon-a"><i class="fa fa-list-alt icons"></i>&nbsp;&nbsp; Settings</a>
    </div>
    <div id="main">
        <div class="head">
            <div class="col-div-6">
                <span style="font-size: 30px; cursor: pointer; color: white;" class="nav"> &#9776; Bookings</span>
                <span style="font-size: 30px; cursor: pointer; color: white;" class="nav2"> &#9776; Bookings</span>
            </div>
        <div class="col-div-6">

        <div class="profile">
            <img src=""  alt="MY picture!" class="pro-img">
            <p>Wiredu Derrick Sarfo<span> Admin</span></p>
        </div>

        <div class="clearfix"></div>
    </div>
        <div>
            <Button name="add_room">Book a Room</Button>
        </div>
        
    <div class="container">
        <div class="row">
            <div class="col m-auto">
                <div class="card mt-5">
                    <div class="card-title">
                        <h3 class="bg-secondary text-white text-center py-3">Bookings</h3>
                    </div>
                    <div class="card-body">
                        <!-- <p><a class="btn btn-info text-area" href="CRUD_FORM.php">+ Add New Record </a> </p> -->
                        <table class="table table-bordered">
                        <tr>
                            <td>User ID</td>
                            <td>Time</td>
                            <td>Room Type</td>
                            <td>Customer name</td>
                            <td>Customer Email</td>
                            <td>Phone</td>
                            <td>Additional Details</td>
                        </tr>
                        <?php
                            while($row = mysqli_fetch_assoc($result))
                            {
                                //$UserID = $row['user_id'];
                                $RoomType = $row['room_type'];
                                $ClientName = $row['name'];
                                $Email = $row['email'];
                                $date = $row['date'];
                                $time = $row['time'];
                                //$AddInfo = $row['message'];

                                ?>

                                <tr>
                                    <td>ID</td>
                                    <td><?php echo$time ?></td>
                                    <td><?php echo $RoomType ?></td>
                                    <td><?php echo $ClientName?></td>
                                    <td><?php echo $Email ?></td>
                                    <td><?php echo $date ?></td>
                                    <td><?php echo $time ?></td>
                                    <td>
                                        <a class="btn btn-info text-white" href="edit.php?GetID=<?php echo $UserID ?>">Edit</a> | <a class="btn btn-danger text-white" href="delele.php?Del=<?php echo $UserID ?>">Delete </a>
                                    </td>
                                </tr>  
                                <?php 
                            } ?>
                        </table>
                       
                    </div>   
                </div>
            </div>     
        </div><br><br><br>
                            <div class="banner">
                              <p style="font-size: 30px;">Book a Room</p>
                            </div>                                         
        <form action="book_pro.php" method="post">
            <div class="form-first">
                <div class="details personal">

                    <div class="fields">
                        <div class="input-field">
                            <label>Full Name</label>
                            <input type="text" name="name" placeholder="Enter guest name" required>
                        </div>

                        <div class="input-field">
                            <label for="options">Room Type</label>
                                <select id="options" name="room_type">
                                    <option value="option2">Select</option>
                                    <option value="option1">Single</option>
                                    <option value="option2">Double</option>
                                    <option value="option3">Quad</option>
                                    <option value="option4">King</option>
                                    <option value="option3">Suite</option>
                                    <option value="option4">Villa</option>
                                </select>
                        </div>

                        <div class="input-field">
                            <label for="options">Total Members</label>
                                <select id="options" name="options">
                                    <option value="option1">Select</option>
                                    <option value="option2">1</option>
                                    <option value="option2">2</option>
                                    <option value="option3">3</option>
                                    <option value="option4">4</option>
                                    <option value="option3">5</option>
                                </select>
                        </div>

                        <div class="input-field">
                            <label>Date</label>
                            <input type="date" placeholder="enter date of booking" required>
                        </div>

                        <div class="input-field">
                            <label>Time</label>
                            <input type="text" name="time" placeholder="enter time of booking">
                        </div>
                    </div>
                </div>

                <div class="details id">
                    <span class="title">Other Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Guest Arrival Date</label>
                            <input type="date" name="date" placeholder="select guest arrival date" required>
                        </div>

                        <div class="input-field">
                            <label>Guest Departure Date</label>
                            <input type="date" placeholder="select guest departure date" required>
                        </div>

                        <div class="input-field">
                            <label>Guest Email ID</label>
                            <input type="text" name="email" placeholder="enter guest id">
                        </div>

                        <div class="input-field">
                            <label>Phone Number</label>
                            <input type="number" name="phone" placeholder="enter a valid phone number" required>
                        </div>

                        <div class="input-field">
                            <label>Expiry Date</label>
                            <input type="date" placeholder="select expiry date">
                        </div>

                        <div class="input-field">
                            <label>Message</label>
                            <textarea rows="5" id="options" name="message"></textarea>
                        </div>
                    </div>

                    <button class="nextBtn" type="submit" name="submit">
                        <span class="btnText"><a href="bookings.html">Next</span>
                        <i class="uil uil-navigator"></i>
                    </button>
                </div>
            </div>
        </form>



<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>

  </div>


    </div>

    </div>

        
        

</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(".nav").click(function(){
        $("#MySideNav").css('width','70px');
        $("#main").css('margin-left','70px');
        $(".logo").css('visibility','hidden');
        $(".logo span").css('visibility','visible');
        $(".logo span").css('margin-left','-10px');
        $(".icon-a").css('visibility','hidden');
        $(".icons").css('visibility','visible');
        $(".icons").css('margin-left','-8px');
        $(".nav").css('display','none');
        $(".nav2").css('display','block');
    });

    $(".nav2").click(function(){
        $("#MySideNav").css('width','300px');
        $("#main").css('margin-left','300px');
        $(".logo").css('visibility','visible');
        $(".logo span").css('visibility','visible');
        $(".icon-a").css('visibility','visible');
        $(".icons").css('visibility','visible');
        $(".nav").css('display','block');
        $(".nav2").css('display','none');
    });
</script>

</body>
</html>