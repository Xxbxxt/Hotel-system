<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seaside Hotel Room</title>
    <link rel="stylesheet" href="rooms.css">
</head>
<body>
<header>
    <div class="hotel-logo"><a href="login page/login page.php"><img src="\IMG\hotel logo.png" alt="LOGO" width="25px"></a>Seashore hotel</div>
      <ul>
        <a href="../Homepage.html">Home</a>
        <a href="#">About</a>
        <a href="../contact/contact.php">Contact</a>
        <a href="../room/rooms.php">rooms</a>
      </ul>
      <button><a href="../Booking.php">Book here</a></button>
    </header>
    
    <main>
        <h1 class="select-rooms">Select Rooms</h1>
        <div class="image-pair">
            <div class="image-container">
                <div class="image-text">ONLY 3 ROOMS LEFT</div>
                <img src="images/room1-1.jpg" alt="Image 1" class="image">
                <img src="images/room1.1.jpg" alt="Hover Image 1" class="hover-image">
                <div class="bottom-text">1 guests 90 ft²</div>
                
            </div>
            <div class="image-container">
                <div class="image-text">4 ROOMS LEFT</div>
                <img src="images/room2.jpg" alt="Image 2" class="image">
                <img src="images/room2.2.jpg" alt="Hover Image 2" class="hover-image">
                <div class="bottom-text">2 guests 90 ft²</div>
               
            </div>
        </div>
        <div class="image-pair">
            <div class="image-container">
                <div class="image-text">ONLY 1 ROOM LEFT</div>
                <img src="images/room3.jpg" alt="Image 3" class="image">
                <img src="images/room3.3.jpg" alt="Hover Image 3" class="hover-image">
                <div class="bottom-text">3 guests 90 ft²</div>
            
            </div>
            <div class="image-container">
                <div class="image-text">7 ROOMS LEFT</div>
                <img src="images/room4.jpg" alt="Image 4" class="image">
                <img src="images/room4.4.jpg" alt="Hover Image 4" class="hover-image">
                <div class="bottom-text">4 guests 90 ft²</div>
               
            </div>
        </div>
        <div class="image-pair">
            <div class="image-container">
                <div class="image-text">ONLY 2 ROOMS LEFT</div>
                <img src="images/room5.jpg" alt="Image 5" class="image">
                <img src="images/room5.5.jpg" alt="Hover Image 5" class="hover-image">
                <div class="bottom-text">5 guests 90 ft²</div>
            </div>
            <div class="image-container">
                <div class="image-text">ONLY 2 ROOMS LEFT</div>
                <img src="images/room6.jpg" alt="Image 6" class="image">
                <img src="images/room6.6.jpg" alt="Hover Image 6" class="hover-image">
                <div class="bottom-text">6 guests 90 ft²</div>
              
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 our hotel. All rights reserved.</p>
    </footer>
</body>
</html>
